import React, { Component } from 'react';


class SelectedItem extends Component {
  render() {
    return (
      <div>
        
      </div>
    );
  }
}


export default SelectedItem;
import React, { Component } from 'react';
import DeliveryFrom from './containers/DeliveryFrom'
import DeliveryTo from './containers/DeliveryTo'

class App extends Component {
  render() {
    return (
      <div>
        <DeliveryFrom />
        <DeliveryTo />
      </div>
    );
  }
}

export default App;
